var jugador2
var GPMTHC
import { score } from "./cliente.js"
export class LP1 extends Phaser.Scene
{
    uName
    conectado
    punt
    constructor()
    {
        super({key: 'LP1'})
    }
    init(data)
    {
         jugador2 = data.p2;
         GPMTHC = data.GPMTHT;
         this.uName= data.uName
         this.conectado = data.sesion
         this.punt = data.punt;
    }
    preload(){
        this.load.image('loading', 'assets/UI/fondo.jpg');
        this.load.image('JBT', 'assets/UI/jugar.png');
        this.load.image('CPP', 'assets/UI/RobotConFondo.png');
        this.load.image('HPP', 'assets/UI/JapoConFondo.png');
        this.load.image('PPP', 'assets/UI/Rusaconfondo.png');
        this.load.image('ganador','assets/UI/GANADOR.png');
        this.load.image('jugador2','assets/UI/jugador2.png');
    }
    create(){
        GPMTHC.stop();
        this.add.image(324, 228, 'loading');
        switch(jugador2)
        {
            case 1:
                this.add.image(324, 228+30, 'HPP');
                break;
            case 2:
                this.add.image(324, 228+30, 'CPP');
                break;
            case 3:
                this.add.image(324, 228+30, 'PPP');
                break;
        }
        this.add.image(324, 30, 'ganador').setScale(0.7);
        this.add.image(324, 30+55, 'jugador2').setScale(0.7);
        score({uName:this.uName,punt:this.punt})
        let playButton = this.add.image(4*(648/8), 2.8*(456/3), 'JBT').setScale(0.5);
        playButton.setInteractive();
        playButton.on('pointerup', () =>{this.scene.start('load')})
    }
    update(){
        
    }
}