var bombCD1 = false;
var bombCD2 = false;
var time = false;
var time2 = false;
var bX;
var bY;
var bX2;
var bY2;
var bR = 1;
var bR2 = 1;
var vel1 = 80;
var vel2 = 80;
var personaje = 3; 
var personaje2 = 3;
var player; 
var player2 ;
var cursors;
var keySpace;
var keyA;
var keyW;
var keyS;
var keyD;
var keyEnter;
var bomba;
var bomba2;
var fire;
var fire2;
var Bbox;
var Ubox;
var plat1;
var vidasp1 = 3;
var vidasp2 = 3;
var tiempodet1 = 2000;
var tiempodet2 = 2000;
var botitas;
var polvorita;
var escudito;
var relojito;
var puntP2Txt;
var puntP1Txt;
var GPMTH
var GPMTHC
// variables sistema puntuacion
var puntuacion = 0;
var puntuacion2 = 0;
var ptcaja = 5;
var ptpowerup = 5;
var ptkill = 30;
var ptdead = -10;
var inv = false;
var inv2 = false;
var lon;
var lon2;
var aleatorio;
var aleatorio2;
var probesc = 50;
var probbotas = 35;
var probreloj = 20;
var probpolvora = 5;

export class fase3 extends Phaser.Scene
{

    uName
    conectado

    constructor()
    {
        super({key: 'fase3'})
    }
    
init(data){
        personaje = data.p1;
        personaje2 = data.p2;
        puntuacion = data.p1P;
        puntuacion2 = data.p2P;
        vidasp1 = data.p1V;
        vidasp2 = data.p2V;
        GPMTHC = data.GPMTHT;
        console.log(puntuacion);
        console.log(puntuacion2);
        console.log(vidasp1);
        console.log(vidasp2);
        this.conectado = data.sesion;
        this.uName = data.uName;
    }     
 preload ()
{
    this.load.image('background3', 'assets/Map004.png'); //Fondo del nivel
    this.load.image('dwnwall3', 'assets/Map004GPDW.png');//Arena
    this.load.image('interior3', 'assets/Map004GPINT.png');//Arena
    this.load.image('Lwall3', 'assets/Map004GPL.png');//Arena
    this.load.image('Rwall3', 'assets/Map004GPR.png');//Arena
    this.load.image('Upwall3', 'assets/Map004GPUP2.png');//Arena
    this.load.image('ubox','assets/UBox.png');
    this.load.image('bbox','assets/BBox.png');
    this.load.image('star', 'assets/star.png');
    this.load.image('bF', 'assets/Fire.png');
    this.load.image('bF2', 'assets/Fire.png');
    this.load.image('botas', 'assets/Botas.png');
    this.load.image('reloj', 'assets/Reloj.png');
    this.load.image('polvora', 'assets/Polvora.png');
    this.load.image('escudo', 'assets/Escudo.png');
    this.load.spritesheet('dude', 
        'assets/dude2.png',
        { frameWidth: 23, frameHeight: 23 }
    );
    this.load.spritesheet('dude2', 
        'assets/citron.png',
        { frameWidth: 23, frameHeight: 23 }
    );
    this.load.spritesheet('dude3', 
        'assets/dude3.png',
        { frameWidth: 23, frameHeight: 23 }
    );
    this.load.spritesheet('bH', 
        'assets/BH.png',
        { frameWidth: 22, frameHeight: 21 }
    );
    this.load.spritesheet('bS', 
        'assets/BS.png',
        { frameWidth: 21, frameHeight: 21 }
    );
    this.load.spritesheet('bC4', 
        'assets/BC4.png',
        { frameWidth: 22, frameHeight: 21 }
    );
}

create ()
{
    //********* Boundaries************
    /*plat1 = this.physics.add.staticGroup();
    // borde 
    plat1.create(325, 300, 'ground').setScale(1).refreshBody();
    plat1.create(325, 520, 'ground').setScale(1).refreshBody();
    // borde izquierda
    plat1.create(55, 228, 'ground3').setScale(2).refreshBody();
    plat1.create(20, 228, 'ground3').setScale(2).refreshBody();
    // borde
    plat1.create(493, 228, 'ground4').setScale(1).refreshBody();
    plat1.create(493, 228, 'ground4').setScale(1).refreshBody();
    // borde 
    plat1.create(325, 60, 'ground6').setScale(1).refreshBody();*/
    //*************
    GPMTHC.stop(); 
    GPMTH = this.sound.add('GPMTH');
    GPMTH.loop = true;
    GPMTH.volume = 0.1;
    GPMTH.play();
    
    this.add.image(324, 228, 'background3');
    this.add.image(325, 240, 'interior3');
    fire = this.physics.add.staticGroup();
    fire2 = this.physics.add.staticGroup();
    
   // ---------------- Unbreakeable Boxes -----------------
    Ubox = this.physics.add.staticGroup();
                                                           // X Y
    Ubox.create(205,120,'ubox').setScale(0.9).refreshBody(); // 0 0
    Ubox.create(205,168,'ubox').setScale(0.9).refreshBody(); // 0 1
    Ubox.create(205,216,'ubox').setScale(0.9).refreshBody(); // 0 2
    Ubox.create(205,264,'ubox').setScale(0.9).refreshBody(); // 0 3
    Ubox.create(205,312,'ubox').setScale(0.9).refreshBody(); // 0 4
    Ubox.create(205,360,'ubox').setScale(0.9).refreshBody(); // 0 5
                                         
    Ubox.create(253,120,'ubox').setScale(0.9).refreshBody(); // 1 0
    Ubox.create(253,168,'ubox').setScale(0.9).refreshBody(); // 1 1
    Ubox.create(253,216,'ubox').setScale(0.9).refreshBody(); // 1 2
    Ubox.create(253,264,'ubox').setScale(0.9).refreshBody(); // 1 3
    Ubox.create(253,312,'ubox').setScale(0.9).refreshBody(); // 1 4
    Ubox.create(253,360,'ubox').setScale(0.9).refreshBody(); // 1 5
                                         
    Ubox.create(301,120,'ubox').setScale(0.9).refreshBody(); // 2 0
    Ubox.create(301,168,'ubox').setScale(0.9).refreshBody(); // 2 1
    Ubox.create(301,216,'ubox').setScale(0.9).refreshBody(); // 2 2
    Ubox.create(301,264,'ubox').setScale(0.9).refreshBody(); // 2 3
    Ubox.create(301,312,'ubox').setScale(0.9).refreshBody(); // 2 4
    Ubox.create(301,360,'ubox').setScale(0.9).refreshBody(); // 2 5
                                         
    Ubox.create(349,120,'ubox').setScale(0.9).refreshBody(); // 3 0
    Ubox.create(349,168,'ubox').setScale(0.9).refreshBody(); // 3 1
    Ubox.create(349,216,'ubox').setScale(0.9).refreshBody(); // 3 2
    Ubox.create(349,264,'ubox').setScale(0.9).refreshBody(); // 3 3
    Ubox.create(349,312,'ubox').setScale(0.9).refreshBody(); // 3 4
    Ubox.create(349,360,'ubox').setScale(0.9).refreshBody(); // 3 5
                                         
    Ubox.create(397,120,'ubox').setScale(0.9).refreshBody(); // 4 0
    Ubox.create(397,168,'ubox').setScale(0.9).refreshBody(); // 4 1
    Ubox.create(397,216,'ubox').setScale(0.9).refreshBody(); // 4 2
    Ubox.create(397,264,'ubox').setScale(0.9).refreshBody(); // 4 3
    Ubox.create(397,312,'ubox').setScale(0.9).refreshBody(); // 4 4
    Ubox.create(397,360,'ubox').setScale(0.9).refreshBody(); // 4 5
                                         
    Ubox.create(445,120,'ubox').setScale(0.9).refreshBody(); // 5 0
    Ubox.create(445,168,'ubox').setScale(0.9).refreshBody(); // 5 1
    Ubox.create(445,216,'ubox').setScale(0.9).refreshBody(); // 5 2
    Ubox.create(445,264,'ubox').setScale(0.9).refreshBody(); // 5 3
    Ubox.create(445,312,'ubox').setScale(0.9).refreshBody(); // 5 4
    Ubox.create(445,360,'ubox').setScale(0.9).refreshBody(); // 5 5
    //----------------------------------------------------------------
    //------------------Breakeable Box--------------------------------
    Bbox = this.physics.add.staticGroup();
                                                           // X Y
    Bbox.create(229,120,'bbox').setScale(1).refreshBody(); // 0 0
    Bbox.create(229,264,'bbox').setScale(1).refreshBody();
    Bbox.create(229,360,'bbox').setScale(1).refreshBody();

    Bbox.create(277,120,'bbox').setScale(1).refreshBody();
    Bbox.create(277,264,'bbox').setScale(1).refreshBody();
    Bbox.create(277,360,'bbox').setScale(1).refreshBody();

    Bbox.create(349,144,'bbox').setScale(1).refreshBody();
    Bbox.create(445,144,'bbox').setScale(1).refreshBody();
    Bbox.create(397,144,'bbox').setScale(1).refreshBody();

    Bbox.create(349,336,'bbox').setScale(1).refreshBody();
    Bbox.create(445,336,'bbox').setScale(1).refreshBody();
    Bbox.create(397,336,'bbox').setScale(1).refreshBody();

    Bbox.create(301,144,'bbox').setScale(1).refreshBody();
    Bbox.create(301,336,'bbox').setScale(1).refreshBody();
    Bbox.create(301,384,'bbox').setScale(1).refreshBody();

    Bbox.create(325,96,'bbox').setScale(1).refreshBody();
    Bbox.create(301,384,'bbox').setScale(1).refreshBody();
    Bbox.create(205,384,'bbox').setScale(1).refreshBody();

    Bbox.create(325,336,'bbox').setScale(1).refreshBody();
    Bbox.create(325,144,'bbox').setScale(1).refreshBody();
    Bbox.create(205,96,'bbox').setScale(1).refreshBody();

    Bbox.create(325,216,'bbox').setScale(1).refreshBody();
    Bbox.create(301,240,'bbox').setScale(1).refreshBody();
    Bbox.create(373,240,'bbox').setScale(1).refreshBody();

    Bbox.create(277,216,'bbox').setScale(1).refreshBody();
    Bbox.create(373,96,'bbox').setScale(1).refreshBody();
    Bbox.create(421,288,'bbox').setScale(1).refreshBody();
    //----------------------------------------------------------------
    //********* Boundaries************
    plat1 = this.physics.add.staticGroup();
    plat1.create(325, 420, 'dwnwall3').setScale(1).refreshBody();
    
    plat1.create(157, 228, 'Lwall3').setScale(1).refreshBody();
    
    plat1.create(493, 228, 'Rwall3').setScale(1).refreshBody();
    
    plat1.create(325, 60, 'Upwall3').setScale(1).refreshBody();
    //************* 
    

   //jugador 1
    // personaje 1
     if (personaje == 1) {
       player = this.physics.add.sprite(181, 96, 'dude');
       this.anims.create({
       key: '3left',
       frames: this.anims.generateFrameNumbers('dude', { start: 4, end: 7 }),
       frameRate: 10,
       repeat: -1
       });
        this.anims.create({
       key: '3right',
       frames: this.anims.generateFrameNumbers('dude', { start: 8, end: 11 }),
       frameRate: 10,
       repeat: -1
       });
        this.anims.create({
        key: '3up',
        frames: this.anims.generateFrameNumbers('dude', { start: 12, end: 15 }),
        frameRate: 10,
        repeat: -1
       });
        this.anims.create({
        key: '3down',
        frames: this.anims.generateFrameNumbers('dude', { start: 0, end: 3 }),
        frameRate: 10,
        repeat: -1
        });
        this.anims.create({
        key: '3stop',
        frames: [ { key: 'dude', frame: 0 } ],
        frameRate: 20
        });
        this.anims.create({
        key: '3red',
        frames: this.anims.generateFrameNumbers('bH', { start: 0, end: 1 }),
        frameRate: 10,
        repeat: -1
        });
        tiempodet1 = tiempodet1/2;
        vel1 = vel1 * 1.5;

      }
     // personaje 2
  
    if (personaje == 2){
       player = this.physics.add.sprite(181, 96, 'dude2');
       this.anims.create({
       key: '3left',
       frames: this.anims.generateFrameNumbers('dude2', { start: 4, end: 7 }),
       frameRate: 10,
       repeat: -1
        });
    this.anims.create({
       key: '3right',
       frames: this.anims.generateFrameNumbers('dude2', { start: 8, end: 11 }),
       frameRate: 10,
       repeat: -1
    });
    this.anims.create({
        key: '3up',
        frames: this.anims.generateFrameNumbers('dude2', { start: 12, end: 15 }),
        frameRate: 10,
        repeat: -1
    });
    this.anims.create({
        key: '3down',
        frames: this.anims.generateFrameNumbers('dude2', { start: 0, end: 3 }),
        frameRate: 10,
        repeat: -1
    });
    this.anims.create({
       key: '3stop',
       frames: [ { key: 'dude2', frame: 0 } ],
       frameRate: 20
    });
    this.anims.create({
        key: '3red',
        frames: this.anims.generateFrameNumbers('bC4', { start: 0, end: 1 }),
        frameRate: 10,
        repeat: -1
    });
    tiempodet1 = 0;
    }
     // Personaje 3
     if (personaje == 3){
           player = this.physics.add.sprite(181, 96, 'dude3');
           this.anims.create({
       key: '3left',
       frames: this.anims.generateFrameNumbers('dude3', { start: 4, end: 7 }),
       frameRate: 10,
       repeat: -1
    });
    this.anims.create({
       key: '3right',
       frames: this.anims.generateFrameNumbers('dude3', { start: 8, end: 11 }),
       frameRate: 10,
       repeat: -1
    });
    this.anims.create({
        key: '3up',
        frames: this.anims.generateFrameNumbers('dude3', { start: 12, end: 15 }),
        frameRate: 10,
        repeat: -1
    });
    this.anims.create({
        key: '3down',
        frames: this.anims.generateFrameNumbers('dude3', { start: 0, end: 3 }),
        frameRate: 10,
        repeat: -1
    });
    this.anims.create({
       key: '3stop',
       frames: [ { key: 'dude3', frame: 0 } ],
       frameRate: 20
    });
    this.anims.create({
        key: '3red',
        frames: this.anims.generateFrameNumbers('bS', { start: 0, end: 1 }),
        frameRate: 10,
        repeat: -1
        });
        bR = bR*2;
	    }

   //jugador 2
    // personaje 1
     if (personaje2 == 1){
     player2 = this.physics.add.sprite(470, 384, 'dude');

     this.anims.create({
       key: '3left2',
       frames: this.anims.generateFrameNumbers('dude', { start: 4, end: 7 }),
       frameRate: 10,
       repeat: -1
    });
    this.anims.create({
       key: '3right2',
       frames: this.anims.generateFrameNumbers('dude', { start: 8, end: 11 }),
       frameRate: 10,
       repeat: -1
    });
    this.anims.create({
        key: '3up2',
        frames: this.anims.generateFrameNumbers('dude', { start: 12, end: 15 }),
        frameRate: 10,
        repeat: -1
    });
    this.anims.create({
        key: '3down2',
        frames: this.anims.generateFrameNumbers('dude', { start: 0, end: 3 }),
        frameRate: 10,
        repeat: -1
    });
    this.anims.create({
       key: '3stop2',
       frames: [ { key: 'dude', frame: 0 } ],
       frameRate: 20
    });
    this.anims.create({
        key: '3red2',
        frames: this.anims.generateFrameNumbers('bH', { start: 0, end: 1 }),
        frameRate: 10,
        repeat: -1
    });
    tiempodet2 = tiempodet2/2;
    vel2 = vel2 * 1.5;

    }
     // personaje 2
     if (personaje2 == 2){
     player2 = this.physics.add.sprite(470, 384, 'dude2');
     this.anims.create({
       key: '3left2',
       frames: this.anims.generateFrameNumbers('dude2', { start: 4, end: 7 }),
       frameRate: 10,
       repeat: -1
    });
    this.anims.create({
       key: '3right2',
       frames: this.anims.generateFrameNumbers('dude2', { start: 8, end: 11 }),
       frameRate: 10,
       repeat: -1
    });
    this.anims.create({
        key: '3up2',
        frames: this.anims.generateFrameNumbers('dude2', { start: 12, end: 15 }),
        frameRate: 10,
        repeat: -1
    });
    this.anims.create({
        key: '3down2',
        frames: this.anims.generateFrameNumbers('dude2', { start: 0, end: 3 }),
        frameRate: 10,
        repeat: -1
    });
    this.anims.create({
       key: '3stop2',
       frames: [ { key: 'dude2', frame: 0 } ],
       frameRate: 20
    });
    this.anims.create({
        key: '3red2',
        frames: this.anims.generateFrameNumbers('bC4', { start: 0, end: 1 }),
        frameRate: 10,
        repeat: -1
    });
    tiempodet2 = 0;
    }
    // Personaje 3
     if (personaje2 == 3){
     player2 = this.physics.add.sprite(470, 384, 'dude3');
     this.anims.create({
       key: '3left2',
       frames: this.anims.generateFrameNumbers('dude3', { start: 4, end: 7 }),
       frameRate: 10,
       repeat: -1
    });
    this.anims.create({
       key: '3right2',
       frames: this.anims.generateFrameNumbers('dude3', { start: 8, end: 11 }),
       frameRate: 10,
       repeat: -1
    });
    this.anims.create({
        key: '3up2',
        frames: this.anims.generateFrameNumbers('dude3', { start: 12, end: 15 }),
        frameRate: 10,
        repeat: -1
    });
    this.anims.create({
        key: '3down2',
        frames: this.anims.generateFrameNumbers('dude3', { start: 0, end: 3 }),
        frameRate: 10,
        repeat: -1
    });
    this.anims.create({
       key: '3stop2',
       frames: [ { key: 'dude3', frame: 0 } ],
       frameRate: 20
    });
    this.anims.create({
        key: '3red2',
        frames: this.anims.generateFrameNumbers('bS', { start: 0, end: 1 }),
        frameRate: 10,
        repeat: -1
    });
        bR2 = bR2 * 2;
	}
   

  //Fisicas del sprite
   // Jugador 1
   player.setBounce(0);
   player.setCollideWorldBounds(true);
   this.physics.add.collider(player, plat1);
   
   this.physics.add.collider(player, Ubox);
   this.physics.add.collider(player, Bbox);
   this.physics.add.collider(player2, Bbox);
   
    // Jugador 2
   player2.setBounce(0);
   player2.setCollideWorldBounds(true);
   this.physics.add.collider(player2, plat1);
   this.physics.add.collider(player2, Ubox);

  // fisicas elementos
    this.physics.add.overlap(Ubox,fire,deletFire,null,this);
    this.physics.add.overlap(plat1,fire,deletFire,null,this);
    this.physics.add.overlap(Bbox,fire,deletBox,null,this);
    this.physics.add.overlap(player,fire,die,null,this);
    this.physics.add.overlap(player,fire2,kill,null,this);

    //fire2
    this.physics.add.overlap(Ubox,fire2,deletFire2,null,this);
    this.physics.add.overlap(plat1,fire2,deletFire2,null,this);
    this.physics.add.overlap(Bbox,fire2,deletBox2,null,this);
    this.physics.add.overlap(player2,fire2,die2,null,this);
    this.physics.add.overlap(player2,fire,kill2,null,this);   
  //movimiento personaje
   cursors = this.input.keyboard.createCursorKeys();
   keySpace = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE); 
   keyA = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A);
   keyD = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D);
   keyS = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S);
   keyW = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W);
   keyEnter = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ENTER);
   //Bombas
   bomba =  this.physics.add.sprite(800, 800, 'bH');
   bomba2 =  this.physics.add.sprite(800, 800, 'bS');

   // powerups

    botitas = this.physics.add.staticGroup();
    relojito = this.physics.add.staticGroup();
    polvorita = this.physics.add.staticGroup();
    escudito = this.physics.add.staticGroup();
    this.physics.add.overlap(player, botitas, collectBotas, null, this);
    this.physics.add.overlap(player2, botitas, collectBotas2, null, this);
    this.physics.add.overlap(player, relojito, collectreloj, null, this);
    this.physics.add.overlap(player2, relojito, collectreloj2, null, this);
    this.physics.add.overlap(player, polvorita, collectpolvora, null, this);
    this.physics.add.overlap(player2, polvorita, collectpolvora2, null, this);
    this.physics.add.overlap(player, escudito, collectescudo, null, this);
    this.physics.add.overlap(player2, escudito, collectescudo2, null, this);
    //this.add.image(25, 20, 'puntP1Txt').setScale(0.5);
    this.add.text(10, 15, this.uName+':', { color: 'white', fontFamily: 'Arial', fontSize: '20px '})
    this.add.image(550, 20, 'puntP2Txt').setScale(0.5);
    puntP1Txt = this.add.text(25+58,20);
    puntP2Txt = this.add.text(550+58,20);
  }

 update ()
{
    var timedEvent3 = this.time.delayedCall(240000, function()
    {
        if(puntuacion > puntuacion2)
{
    
    this.scene.start('LP2',{p1:personaje,GPMTHT:GPMTH,uName:this.uName,sesion:this.conectado,punt:puntuacion});
}
else if(puntuacion < puntuacion2)
{
    
    this.scene.start('LP1',{p2:personaje2,GPMTHT:GPMTH,uName:this.uName,sesion:this.conectado,punt:puntuacion});
}
else
{
    
    this.scene.start('DRAW',{p1:personaje,p2:personaje2,GPMTHT:GPMTH,uName:this.uName,sesion:this.conectado,punt:puntuacion}); 
}
    } , [], this);
    puntP1Txt.setText(puntuacion);
    puntP2Txt.setText(puntuacion2);
 // jugador 1 movimiento   
    if (keyA.isDown)
    {
       player.setVelocityX(-vel1);
       //player.setVelocityY(0);
       player.anims.play('3left', true);
    }
    else if (keyD.isDown)
    {
       player.setVelocityX(vel1);
       //player.setVelocityY(0);
       player.anims.play('3right', true);
    }
    else if (keyW.isDown)
    {
       player.setVelocityY(-vel1);
       //player.setVelocityX(0);
       player.anims.play('3up', true);
    }
    else if (keyS.isDown)
    {
       player.setVelocityY(vel1);
       //player.setVelocityX(0);
       player.anims.play('3down', true);
    }
     else
    {
       player.setVelocityX(0);
       player.setVelocityY(0);
       player.anims.play('3stop');
    }
    if (keySpace.isDown && bombCD1 == false)
    {
        
        console.log(player.x);
        console.log(player.y);
        bomba.x = player.x;
        bomba.y = player.y; 
        bX = bomba.x ;
        bY = bomba.y; 
        bomba.anims.play('3red');
        if (tiempodet1==0){
        var timedEvent3 = this.time.delayedCall(400, cambiarcd, [], this);
        }
        if (tiempodet1>0){
        
        var timedEvent = this.time.delayedCall(tiempodet1, unSet, [], this);
        var timedEvent2 = this.time.delayedCall(tiempodet1+1000, function(){fire.children.iterate(function(child){child.disableBody(true,true)})} , [], this);
        bombCD1 = true;
        }
     }
     if (keySpace.isDown && bombCD1 == true && tiempodet1 == 0){
     var timedEvent = this.time.delayedCall(200, unSet, [], this);
     var timedEvent2 = this.time.delayedCall(1000, function(){fire.children.iterate(function(child){child.disableBody(true,true)})} , [], this);
     }
	 
   // Jugador 2 movimiento
   if (cursors.left.isDown)
   {
       player2.setVelocityX(-vel2);
       player2.setVelocityY(0);
       player2.anims.play('3left2', true);
   }
   else if (cursors.right.isDown)
   {
       player2.setVelocityX(vel2);
       player2.setVelocityY(0);
       player2.anims.play('3right2', true);
   }
   else if (cursors.up.isDown)
   {
       player2.setVelocityY(-vel2);
       player2.setVelocityX(0);
       player2.anims.play('3up2', true);
   }
   else if (cursors.down.isDown)
   {
       player2.setVelocityY(vel2);
       player2.setVelocityX(0);
       player2.anims.play('3down2', true);
   }
   else
   {
       player2.setVelocityX(0);
       player2.setVelocityY(0);
       player2.anims.play('3stop2');
   }
   if (keyEnter.isDown && bombCD2 == false)
    {
        
        console.log(player2.x);
        console.log(player.y);
        bomba2.x = player2.x;
        bomba2.y = player2.y; 
        bX2 = bomba2.x ;
        bY2 = bomba2.y; 
        bomba2.anims.play('3red2');
    if (tiempodet2==0){
        var timedEvent3 = this.time.delayedCall(400, cambiarcd2, [], this);
        }
        if (tiempodet2>0){
        
        var timedEvent = this.time.delayedCall(tiempodet2, unSet2, [], this);
        var timedEvent2 = this.time.delayedCall(tiempodet2+1000, function(){fire2.children.iterate(function(child){child.disableBody(true,true)})} , [], this);
        bombCD2 = true;
        }
     }
     if (keyEnter.isDown && bombCD2 == true && tiempodet2 == 0){
     var timedEvent = this.time.delayedCall(200, unSet2, [], this);
     var timedEvent2 = this.time.delayedCall(1000, function(){fire2.children.iterate(function(child){child.disableBody(true,true)})} , [], this);
     }
    

}
}
function unSet()
{
    bomba.x = 800;
    bomba.y = 800; 
    bombCD1 = false;
    detonar();
}
function unSet2()
{
    bomba2.x = 800;
    bomba2.y = 800; 
    bombCD2 = false;
    detonar2();
}
function detonar ()
{
    console.log('booom');
    /*switch(bR)
    {
        case 1 :
            fire.create(bX,bY,'bF').setScale(1).refreshBody();
            fire.create(bX,bY + 24,'bF').setScale(1).refreshBody();
            fire.create(bX,bY - 24,'bF').setScale(1).refreshBody();
            fire.create(bX + 24,bY,'bF').setScale(1).refreshBody();
            fire.create(bX - 24,bY,'bF').setScale(1).refreshBody();            break;
        case 2 :
            fire.create(bX,bY,'bF').setScale(1).refreshBody();
            fire.create(bX,bY + 24,'bF').setScale(1).refreshBody();
            fire.create(bX,bY - 24,'bF').setScale(1).refreshBody();
            fire.create(bX + 24,bY,'bF').setScale(1).refreshBody();
            fire.create(bX - 24,bY,'bF').setScale(1).refreshBody();
            // siguiente linea
            fire.create(bX,bY + 48,'bF').setScale(1).refreshBody();
            fire.create(bX,bY - 48,'bF').setScale(1).refreshBody();
            fire.create(bX + 48,bY,'bF').setScale(1).refreshBody();
            fire.create(bX - 48,bY,'bF').setScale(1).refreshBody();
            break;
    }*/
    for (var i = bR, lon = 1; i>0 ;  i--, lon++) {
    fire.create(bX,bY,'bF').setScale(1).refreshBody();
            fire.create(bX,bY + 24*lon,'bF').setScale(1).refreshBody();
            fire.create(bX,bY - 24*lon,'bF').setScale(1).refreshBody();
            fire.create(bX + 24*lon,bY,'bF').setScale(1).refreshBody();
            fire.create(bX - 24*lon,bY,'bF').setScale(1).refreshBody();
	}
}
function detonar2 ()
{
    console.log('booom');
    switch(bR2)
    {
        case 1 :
            fire2.create(bX2,bY2,'bF2').setScale(1).refreshBody();
            fire2.create(bX2,bY2 + 24,'bF2').setScale(1).refreshBody();
            fire2.create(bX2,bY2 - 24,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 + 24,bY2,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 - 24,bY2,'bF2').setScale(1).refreshBody();
            break;
        case 2 :
            fire2.create(bX2,bY2,'bF2').setScale(1).refreshBody();
            fire2.create(bX2,bY2 + 24,'bF2').setScale(1).refreshBody();
            fire2.create(bX2,bY2 - 24,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 + 24,bY2,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 - 24,bY2,'bF2').setScale(1).refreshBody();
            // siguiente linea
            fire2.create(bX2,bY2 + 48,'bF2').setScale(1).refreshBody();
            fire2.create(bX2,bY2 - 48,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 + 48,bY2,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 - 48,bY2,'bF2').setScale(1).refreshBody();
            break;
        case 3 :
            fire2.create(bX2,bY2,'bF2').setScale(1).refreshBody();
            fire2.create(bX2,bY2 + 24,'bF2').setScale(1).refreshBody();
            fire2.create(bX2,bY2 - 24,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 + 24,bY2,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 - 24,bY2,'bF2').setScale(1).refreshBody();
            // siguiente linea
            fire2.create(bX2,bY2 + 48,'bF2').setScale(1).refreshBody();
            fire2.create(bX2,bY2 - 48,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 + 48,bY2,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 - 48,bY2,'bF2').setScale(1).refreshBody();
            // siguiente linea
            fire2.create(bX2,bY2 + 72,'bF2').setScale(1).refreshBody();
            fire2.create(bX2,bY2 - 72,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 + 72,bY2,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 - 72,bY2,'bF2').setScale(1).refreshBody();
            break;
        case 4 :
            fire2.create(bX2,bY2,'bF2').setScale(1).refreshBody();
            fire2.create(bX2,bY2 + 24,'bF2').setScale(1).refreshBody();
            fire2.create(bX2,bY2 - 24,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 + 24,bY2,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 - 24,bY2,'bF2').setScale(1).refreshBody();
            // siguiente linea
            fire2.create(bX2,bY2 + 48,'bF2').setScale(1).refreshBody();
            fire2.create(bX2,bY2 - 48,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 + 48,bY2,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 - 48,bY2,'bF2').setScale(1).refreshBody();
            // siguiente linea
            fire2.create(bX2,bY2 + 72,'bF2').setScale(1).refreshBody();
            fire2.create(bX2,bY2 - 72,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 + 72,bY2,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 - 72,bY2,'bF2').setScale(1).refreshBody();
            // siguiente linea
            fire2.create(bX2,bY2 + 96,'bF2').setScale(1).refreshBody();
            fire2.create(bX2,bY2 - 96,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 + 96,bY2,'bF2').setScale(1).refreshBody();
            fire2.create(bX2 - 96,bY2,'bF2').setScale(1).refreshBody();
            break;

    }
}
/*function deletFire (Ubox,fire) 
{
    fire.disableBody(true,true);
}*/


function die (player,fire) 
{
    
    if (inv == false){
    vidasp1 = vidasp1 - 1;
    puntuacion2 = puntuacion2 + ptkill;
    console.log(puntuacion2);
    inv = true;
    if (vidasp1> 0){
    player.x = 181;
    player.y = 96;
    }else{
        this.scene.start('LP1',{p2:personaje2,GPMTHT:GPMTH,uName:this.uName,sesion:this.conectado,punt:puntuacion});
    }
    }
    var timedEvent = this.time.delayedCall(2000, reverseinv, [], this);
     
}

function kill (player,fire2) 
{
    if (inv == false){
    vidasp1 = vidasp1 - 1;
    puntuacion2 = puntuacion2 + ptkill;
    console.log(puntuacion2);
    inv = true;
    if (vidasp1> 0){
    player.x = 181;
    player.y = 96;
    }else{
        this.scene.start('LP1',{p2:personaje2,GPMTHT:GPMTH,uName:this.uName,sesion:this.conectado,punt:puntuacion});

    } 
    }
    var timedEvent = this.time.delayedCall(2000, reverseinv, [], this);
    
    
    
}

function die2 (player2,fire2) 
{
   
    if (inv2 == false){
    vidasp2 = vidasp2 - 1;
    puntuacion = puntuacion + ptkill;
    console.log(puntuacion);
    inv2 = true;
    if (vidasp2> 0){
    player2.x = 470;
    player2.y = 384;
    }else{
        this.scene.start('LP2',{p1:personaje,GPMTHT:GPMTH,uName:this.uName,sesion:this.conectado,punt:puntuacion});
    }
    }
    var timedEvent = this.time.delayedCall(2000, reverseinv2, [], this);
     
}

function kill2 (player2,fire) 
{
    if (inv2 == false){
    vidasp2 = vidasp2 - 1;
    puntuacion = puntuacion + ptkill;
    console.log(puntuacion);
    inv2 = true;
    if (vidasp2> 0){
    player2.x = 470;
    player2.y = 384;
    }else{
        this.scene.start('LP2',{p1:personaje,GPMTHT:GPMTH,uName:this.uName,sesion:this.conectado,punt:puntuacion});
    }
    }
    var timedEvent = this.time.delayedCall(2000, reverseinv2, [], this);
     

}


function deletFire (Ubox,fire) 
{
    fire.disableBody(true,true);
}
function deletFire2 (Ubox,fire2) 
{
    fire2.disableBody(true,true);
}
function deletBox (fire) 
{
    fire.disableBody(true,true);
    puntuacion = puntuacion + ptcaja;
    console.log(puntuacion);
    aleatorio = Math.floor(Math.random() * 100);
    if (aleatorio < probpolvora){
    polvorita.create(bX, bY, 'polvora').setScale(0.01).refreshBody();
    } else if (aleatorio < probreloj){
    relojito.create(bX, bY, 'reloj').setScale(0.01).refreshBody();
    }else if (aleatorio < probbotas){
    botitas.create(bX, bY, 'botas').setScale(0.01).refreshBody();
    } else if (aleatorio < probesc){
    escudito.create(bX, bY, 'escudo').setScale(0.01).refreshBody();
    }
}
function deletBox2 (fire2) 
{
    fire2.disableBody(true,true);
    puntuacion2 = puntuacion2 + ptcaja;
    console.log(puntuacion2);
    aleatorio2 = Math.floor(Math.random() * 100);
    if (aleatorio2 < probpolvora){
    polvorita.create(bX2, bY2, 'polvora').setScale(0.01).refreshBody();
    } else if (aleatorio2 < probreloj){
    relojito.create(bX2, bY2, 'reloj').setScale(0.01).refreshBody();
    }else if (aleatorio2 < probbotas){
    botitas.create(bX2, bY2, 'botas').setScale(0.01).refreshBody();
    } else if (aleatorio2 < probesc){
    escudito.create(bX2, bY2, 'escudo').setScale(0.01).refreshBody();
    }
}
function collectBotas(player, botas) {
    botas.disableBody(true, true);
    vel1 = vel1 * 1.3;
    puntuacion = puntuacion + ptpowerup;
    console.log(puntuacion);
}
function collectBotas2(player2, botas) {
    botas.disableBody(true, true);
    vel2 = vel2 * 1.3;
    puntuacion2 = puntuacion2 + ptpowerup;
    console.log(puntuacion2);
}
function collectreloj(player, reloj) {
    reloj.disableBody(true, true);
    tiempodet1 = tiempodet1 /1.25;
    puntuacion = puntuacion + ptpowerup;
    console.log(puntuacion);
}
function collectreloj2(player2, reloj) {
    reloj.disableBody(true, true);
    tiempodet2 = tiempodet2 /1.25;
    puntuacion2 = puntuacion2 + ptpowerup;
    console.log(puntuacion2);
}
function collectescudo(player, escudo) {
    escudo.disableBody(true, true);
    puntuacion = puntuacion + ptpowerup;
    console.log(puntuacion);
    inv = true;
    var timedEvent = this.time.delayedCall(10000, reverseinv, [], this);
}
function collectescudo2(player2, escudo) {
    escudo.disableBody(true, true);
    inv2 = true;
    var timedEvent = this.time.delayedCall(10000, reverseinv2, [], this);
    puntuacion2 = puntuacion2 + ptpowerup;
    console.log(puntuacion2);
}
function collectpolvora(player, polvora) {
    polvora.disableBody(true, true);
    puntuacion = puntuacion + ptpowerup;
    console.log(puntuacion);
    bR++;
}
function collectpolvora2(player2, polvora) {
    polvora.disableBody(true, true);
    bR2 = bR2 +1;
    puntuacion2 = puntuacion2 + ptpowerup;
    console.log(puntuacion2);
   } 
function cambiarcd() {
    bombCD1 = true;

}
function cambiarcd2() {
    bombCD2 = true;

}
function reverseinv() {
    inv = false;

}
function reverseinv2() {
    inv2 = false;

}


/*function bombas (x , y)
{
bomba =  this.physics.add.sprite(x, y, 'bH');
this.anims.create({
    key: 'red',
    frames: this.anims.generateFrameNumbers('BH', { start: 0, end: 1 }),
    frameRate: 10,
    repeat: -1
});
}*/
