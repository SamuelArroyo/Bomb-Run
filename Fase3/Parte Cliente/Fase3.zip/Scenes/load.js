//import { cUser } from "./cliente.js";
import { rUsers } from "./cliente.js";
export class load extends Phaser.Scene
{
    conectado = false
    uName 
    a
    constructor()
    {
        super({key: 'load'})
    }
    init(data){
       this.conectado = data.sesion;
       this.uName = data.uName;
       this.a = data.BMGT;
    }
    preload(){
        this.load.image('loading', 'assets/UI/fondo.jpg');
        this.load.image('JBT', 'assets/UI/jugar.png');
        this.load.image('TBT', 'assets/UI/tutorial.png');
        this.load.image('LBT', 'assets/UI/login.png');
        this.load.image('OBT', 'assets/UI/opciones.png');
        this.load.image('title', 'assets/UI/title.png');
        this.load.image('SBT', 'assets/UI/salir.png');
        this.load.image('BBT', 'assets/UI/back.png');
        this.load.image('PBT', 'assets/UI/PUNTUACIONES.png');
        this.load.audio('BGMM', 'assets/music/menu.mp3');

    }
    create(){
        var BGM =this.sound.add('BGMM');
       
        BGM.volume = 0.3;
        BGM.loop = true;
        BGM.play();
        this.add.image(324, 228, 'loading');
        this.add.image(324, 100, 'title');
        
        let playButton2 = this.add.image(324+3, 228+40, 'TBT').setScale(0.5);
        let playButton3 = this.add.image(324, 228+75, 'OBT').setScale(0.5);
        let playButton4 = this.add.image(324, 228+75+40, 'SBT').setScale(0.7);
        let playButton6 = this.add.image(140, 430, 'PBT').setScale(0.4);
        
        playButton2.setInteractive();
        playButton3.setInteractive();
        playButton4.setInteractive();
        playButton6.setInteractive();
       
        playButton2.on('pointerup', () =>{this.scene.start('tuto',{BGMT:BGM})})
        playButton3.on('pointerup', () =>{})
        playButton4.on('pointerup', () =>{this.scene.start('load',{sesion:false,uName:'Guest'})})
        playButton6.on('pointerup', () =>{this.scene.start('scores',{BGMT:BGM})})
        if(!this.conectado){
            let playButton5 = this.add.image(580,430,'LBT').setScale(0.4);
            playButton5.setInteractive();
            playButton5.on('pointerup', () =>{this.scene.start('sesion',{BGMT:BGM,uName:this.uName,sesion:this.conectado})})
            let playButton = this.add.image(324, 228, 'JBT').setScale(0.7);
            playButton.setInteractive();
            playButton.on('pointerup', () =>{this.scene.start('CharSelect',{BGMT:BGM,uName:'Guest',sesion:this.conectado})})
        }
        else
        {
            this.add.text(580,420, this.uName, { color: 'white', fontFamily: 'Arial', fontSize: '20px '})
            let playButton = this.add.image(324, 228, 'JBT').setScale(0.7);
            playButton.setInteractive();
            playButton.on('pointerup', () =>{this.scene.start('CharSelect',{BGMT:BGM,uName:this.uName,sesion:this.conectado})})
        }
        
    }
    update(){
        
    }
}