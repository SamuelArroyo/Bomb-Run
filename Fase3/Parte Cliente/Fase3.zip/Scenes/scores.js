//import { hScore } from "./cliente.js";
var enlace = "http://localhost:8080"
export class scores extends Phaser.Scene
{
    hs = ''
    BGMC;

    constructor()
    {
        super({key: 'scores'})
    }

    init(data)
    {
        this.BGMC = data.BGMT;
    }
    preload()
    {
        this.load.image('backScores', 'assets/fondoTuto.png');
        this.load.image('trofeo', 'assets/trofeo.png');
        this.load.image('top5','assets/UI/top5.png')
    }
    create()
    {
        this.hs = hScore()
        this.BGMC.stop();
        this.add.image(324, 228, 'backScores');
        this.add.image(2*(628/3)+50, 258, 'trofeo').setScale(0.6);
        this.add.image(150, 70, 'top5').setScale(1)
        this.add.text(50,130, this.hs, { color: 'white', fontFamily: 'Arial', fontSize: '25px '})
    
        let playButton = this.add.image(608-15, 10+15, 'BBT').setScale(0.5)
        playButton.setInteractive();
        playButton.on('pointerup', () =>{this.scene.start('load')})
        function hScore() {
            var str = ''
            $.ajax({
                url: enlace + "/score",
                async:false
            }).done(function (items) {
                items.sort((a,b)=>(a.hpunt >b.hpunt) ? -1:1)
                console.log(items);
                for (var i = 0 ; i<6;i++){
                    str = str + items[i].uName + ' |---| ' + items[i].hpunt +'\n\n'
                }
                console.log(str)
                
                
               
            });
            return str
        }
        
    }
    update()
    {

    }
}