export class load extends Phaser.Scene
{
    constructor()
    {
        super({key: 'load'})
    }
    init(){}
    preload(){
        this.load.image('loading', 'assets/UI/fondo.jpg');
        this.load.image('JBT', 'assets/UI/jugar.png');
        this.load.image('TBT', 'assets/UI/tutorial.png');
        this.load.image('OBT', 'assets/UI/opciones.png');
        this.load.image('title', 'assets/UI/title.png');
        this.load.image('SBT', 'assets/UI/salir.png');
        this.load.audio('BGMM', 'assets/music/menu.mp3');

    }
    create(){
        var BGM =this.sound.add('BGMM');
        BGM.loop = true;
        BGM.play();
        this.add.image(324, 228, 'loading');
        this.add.image(324, 100, 'title');
        let playButton = this.add.image(324, 228, 'JBT').setScale(0.7);
        let playButton2 = this.add.image(324+3, 228+40, 'TBT').setScale(0.5);
        let playButton3 = this.add.image(324, 228+75, 'OBT').setScale(0.5);
        let playButton4 = this.add.image(324, 228+75+40, 'SBT').setScale(0.7);
        playButton.setInteractive();
        playButton2.setInteractive();
        playButton3.setInteractive();
        playButton4.setInteractive();
        playButton.on('pointerup', () =>{this.scene.start('CharSelect',{BGMT:BGM})})
    }
    update(){
        
    }
}