var jugador2
var jugador
var GPMTHC
export class DRAW extends Phaser.Scene
{
    constructor()
    {
        super({key: 'DRAW'})
    }
    init(data)
    {
         jugador2 = data.p2;
         jugador = data.p1;
         GPMTHC = data.GPMTHT
    }
    preload(){
        this.load.image('loading', 'assets/UI/fondo.jpg');
        this.load.image('JBT', 'assets/UI/jugar.png');
        this.load.image('CPP', 'assets/UI/RobotConFondo.png');
        this.load.image('HPP', 'assets/UI/JapoConFondo.png');
        this.load.image('PPP', 'assets/UI/Rusaconfondo.png');
        this.load.image('empate','assets/UI/EMPATE.png');
        this.load.image('jugador2','assets/UI/jugador2.png');
        this.load.image('jugador','assets/UI/jugador1.png');
    }
    create(){
        GPMTHC.stop();
        this.add.image(324, 228, 'loading');
        switch(jugador2)
        {
            case 1:
                this.add.image(2*(648/3), 228+30, 'HPP');
                break;
            case 2:
                this.add.image(2*(648/3), 228+30, 'CPP');
                break;
            case 3:
                this.add.image(2*(648/3), 228+30, 'PPP');
                break;
        }
        switch(jugador)
        {
            case 1:
                this.add.image(648/3, 228+30, 'HPP');
                break;
            case 2:
                this.add.image(648/3, 228+30, 'CPP');
                break;
            case 3:
                this.add.image(648/3, 228+30, 'PPP');
                break;
        }
        this.add.image(324, 30, 'empate').setScale(0.8);
        this.add.image(648/3, 30+55, 'jugador').setScale(0.4);
        this.add.image(2*(648/3), 30+55, 'jugador2').setScale(0.4);
        
        let playButton = this.add.image(4*(648/8), 2.8*(456/3), 'JBT').setScale(0.5);
        playButton.setInteractive();
        playButton.on('pointerup', () =>{this.scene.start('load')})
    }
    update(){
        
    }
}