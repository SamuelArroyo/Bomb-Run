var keyA;
var keyD;
var player = 1; // 1-H 2-P 3-C
var player2 = 1; // 1-H 2-P 3-C
var cursors;
var BGMC;
var HMTH; 
var PMTH; 
var CMTH;
export class CharSelect extends Phaser.Scene
{
    constructor()
    {
        super({key: 'CharSelect'})
    }
    init(data){
        BGMC = data.BGMT;
    }
    preload(){
        this.load.image('back', 'assets/UI/fondo.jpg');
        this.load.image('Ctext', 'assets/UI/citron.png');
        this.load.image('Htext', 'assets/UI/hirosaki.png');
        this.load.image('Ptext', 'assets/UI/pavli.png');
        this.load.image('flechaL', 'assets/UI/flechaI.png');
        this.load.image('flechaR', 'assets/UI/flechaD.png');
        this.load.image('CPP', 'assets/UI/RobotConFondo.png');
        this.load.image('HPP', 'assets/UI/JapoConFondo.png');
        this.load.image('PPP', 'assets/UI/Rusaconfondo.png');
        this.load.audio('HMTH', 'assets/music/japon.mp3');
        this.load.audio('CMTH', 'assets/music/robot_.mp3');
        this.load.audio('PMTH', 'assets/music/pavlichenko.mp3');
        

    }
    create(){
        BGMC.stop();
         HMTH =this.sound.add('HMTH');
         CMTH =this.sound.add('CMTH');
         PMTH =this.sound.add('PMTH');
        HMTH.loop = true;
        CMTH.loop = true;
        PMTH.loop = true;
        CMTH.play();
        this.add.image(324, 228, 'back');
        //this.add.image(324, 100, 'title');
        let playButton = this.add.image(648/8, 2.7*(456/3), 'flechaL').setScale(0.8);
        let playButton2 = this.add.image(3*(648/8), 2.7*(456/3), 'flechaR').setScale(0.8);
        let playButton3 = this.add.image(5*(648/8), 2.7*(456/3), 'flechaL').setScale(0.8);
        let playButton4 = this.add.image(7*(648/8), 2.7*(456/3), 'flechaR').setScale(0.8);
        let playButton5 = this.add.image(4*(648/8), 2.7*(456/3), 'JBT').setScale(0.3);
        playButton.setInteractive();
        playButton2.setInteractive();
        playButton3.setInteractive();
        playButton4.setInteractive();
        playButton5.setInteractive();
        playButton5.on('pointerup', () =>{this.scene.start('fase1',{p1: player,p2:player2})});
        playButton.on('pointerup', () =>{
            player--;
            if(player < 1){player = 3;} 
            console.log(player);});
        playButton2.on('pointerup', () =>
            {player++;
            if(player > 3){player = 1;}
            console.log(player);});
        playButton3.on('pointerup', () =>{
            player2--; 
            if(player2 < 1){player2 = 3;} 
            console.log(player2);});
        playButton4.on('pointerup', () =>{
            player2++;
            if(player2 > 3){player2 = 1;} 
            console.log(player2);});
            
   
    }
    update(){
        
        switch(player){
            case 1:
                 var CP1 = this.physics.add.sprite(648/4, 456/2.3, 'HPP');
                 
                break;
            case 2:
                 CP1 = this.physics.add.sprite(648/4, 456/2.3, 'CPP');
                 
                break;
            case 3:
                 CP1 = this.physics.add.sprite(648/4, 456/2.3, 'PPP');
                 
                break;
        }
        switch(player2){
            case 1:
                 var CP2 = this.physics.add.sprite(3*(648/4), 456/2.3, 'HPP');
                break;
            case 2:
                CP2 = this.physics.add.sprite(3*(648/4), 456/2.3, 'CPP');
                break;
            case 3:
                 
                 CP2 = this.physics.add.sprite(3*(648/4), 456/2.3, 'PPP');
                break;
        }
    }
}