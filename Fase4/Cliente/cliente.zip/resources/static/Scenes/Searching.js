var personaje
var personajeO
var a
var CMTHC;
var enlaceWS = 'ws://localhost:8080/multi'
var encontrado = false
var HMTH 
var connection
var player
var uNameR
export class Searching extends Phaser.Scene
{
    conectado = false
    uName
    uNameR 
    
    constructor()
    {
        super({key: 'Searching'})
    }
    init(data){
        personaje = data.p1;
        CMTHC = data.CMTHT;
        this.conectado = data.sesion;
        
        this.uName = data.uName;
        
        
    }
    preload(){
        this.load.image('backTuto', 'assets/fondoTuto.png');
        this.load.image('busca','assets/UI/BUSCANDO2.png');
        this.load.audio('HMTH', 'assets/music/japon.mp3');
        

    }
    create(){
        CMTHC.stop();
        this.add.image(324, 228, 'backTuto');
        this.add.image(324,228,'busca').setScale(0.7);
        HMTH =this.sound.add('HMTH');
        HMTH.loop = true;
        HMTH.volume = 0.3;
        HMTH.play();
        let playButton = this.add.image(608-15, 10+15, 'BBT').setScale(0.5);
        playButton.setInteractive();
        playButton.on('pointerup', () =>{this.scene.start('load',{uName:this.uName,sesion:this.conectado})})
        connection = new WebSocket(enlaceWS);
        console.log(this.uName);
        a = this.uName
        connection.onopen = function () {
                var msg = {tipo: "buscando", pjS:personaje, uName:a}
                connection.send(JSON.stringify(msg));
                
                
            }
            connection.onerror = function(e) {
                console.log("WS error: " + e);
            }
            
            connection.onmessage = function(msg) {
                if(encontrado==false){
                console.log("WS message: " + msg.data);
               var info = JSON.parse(msg.data)
               
                if (info.tipo == "asignaP"){
                    player = info.nPlayer
                }else if(info.tipo == "game"){
                    personajeO = parseInt(info.pjR)
                    uNameR = info.uNameR
                    encontrado = true
                }
               } 
                 
            }
        
        
    }
    update(){
        if (encontrado){
            if(player == 1){
                this.scene.start('Ofase1',{p1: personaje,p2:personajeO,CMTHT:HMTH,uName:this.uName,uNameR:this.uNameR,sesion:this.conectado,socket:connection,nP:player})
            }else{
                this.scene.start('Ofase1',{p1: personajeO,p2:personaje,CMTHT:HMTH,uName:this.uNameR,uNameR:this.uNamer,sesion:this.conectado,socket:connection,nP:player})
            }
             
        }
        
    }
}